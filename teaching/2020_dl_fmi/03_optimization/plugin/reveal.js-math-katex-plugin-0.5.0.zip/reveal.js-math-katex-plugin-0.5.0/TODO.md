# TODO

- Use the [auto-render extension](https://github.com/Khan/KaTeX/tree/master/contrib/auto-render) that’s now included with KaTeX instead of the custom code in `replaceFormulaTex` (`math-katex.js`).
